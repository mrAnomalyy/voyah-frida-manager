#!/system/bin/sh
# VOYAH H53 - Persistent Root Policy (XDJA IDPS)
DIR=/data/local/tmp
MODDIR=/data/local/voyahmods
ADB_ROOT_FLAG=$MODDIR/enable_adb_root
POLICY_DIR=/mnt/vendor/persist/xdja_idps/data/update/policy
POLICY_SRC=$MODDIR/VoyahBootPolicy_ROOT.tar.gz

# 1. Start Persistent Root Proxy
setsid sh -p -c '
    echo $$ > /acct/tasks 2>/dev/null
    echo -1000 > /proc/self/oom_score_adj 2>/dev/null
    rm -f '"$DIR"'/.cmd '"$DIR"'/.out '"$DIR"'/.ready
    echo $$ > '"$DIR"'/rootshell.pid
    while true; do
        if [ -f '"$DIR"'/.cmd ]; then
            sh -p -c "$(cat '"$DIR"'/.cmd)" > '"$DIR"'/.out 2>&1
            rm -f '"$DIR"'/.cmd
            touch '"$DIR"'/.ready
        fi
        sleep 0.2
    done
' < /dev/null > /dev/null 2>&1 &

i=0
while [ $i -lt 20 ]; do
    [ -s "$DIR/rootshell.pid" ] && break
    sleep 0.1
    i=$((i + 1))
done
[ -s "$DIR/rootshell.pid" ] && touch "$DIR/.ready"

# 2. Check ADB root toggle flag
if [ -f "$ADB_ROOT_FLAG" ]; then
    printf '1' | dd of=/dev/__properties__/u:object_r:exported2_default_prop:s0 bs=1 seek=6896 count=1 conv=notrunc 2>/dev/null
    printf '0' | dd of=/dev/__properties__/u:object_r:exported_secure_prop:s0 bs=1 seek=460 count=1 conv=notrunc 2>/dev/null
    setprop service.adb.root 1
    setprop ctl.restart adbd
fi

# 3. Re-arm policy so it persists across reboots
(
    sleep 10
    if [ -f "$POLICY_SRC" ] && [ -d "$POLICY_DIR" ]; then
        cp "$POLICY_SRC" "$POLICY_DIR/new_policy.tmp" &&         chmod 0644 "$POLICY_DIR/new_policy.tmp" &&         mv -f "$POLICY_DIR/new_policy.tmp" "$POLICY_DIR/new_policy"
    fi
) >/dev/null 2>&1 &

exit 0
